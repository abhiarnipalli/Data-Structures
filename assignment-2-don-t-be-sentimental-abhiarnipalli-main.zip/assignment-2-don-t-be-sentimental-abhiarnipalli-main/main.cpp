#include <iostream>
#include "dictionary.h"
using namespace std;

int main(int argc, char* argv[]){


    cout << argv[0] << endl; //Train
    cout << argv[1] << endl; //test
    cout << argv[2] << endl;//Test_sentiment
    cout << argv[3] << endl; //Classification_output
    cout << argv[4] << endl;// Accuracy output
    Dictionary dict;
    dict.doAllTheTrainingHere(argv[1]);// function to train
    dict.doAllTheTestingHere(//function to test
            argv[2],
            argv[3],
            argv[4],
            argv[5]
    );

}