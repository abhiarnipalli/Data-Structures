#ifndef _H_DICTIONARY
#define _H_DICTIONARY
#include <iostream>
#include "DSString.h"
#include "DSTokenize.h"
#include "DSVector.h"
using namespace std;



class Tweet2
{
public:
    int sentiment;
    DSString ID; // move to private after
    DSString date; // move to private after
    DSString query; // move to private after
    DSString user; // move to private after
    DSString text; // move to private after
    Tweet2() { //constructor
        sentiment = 0;
        text = "";
    };
    Tweet2(int sent, DSString tweet) { // Constructor for data read test
        sentiment = sent;
        text = tweet;
    };
    Tweet2(DSString ID, int sent) //constructor for data read
    {
        (*this).ID = ID;
        sentiment = sent;
    }

    Tweet2(DSString ID, DSString date, DSString query, DSString user, int sent, DSString tweet) { //constructor for reading the data the first time
        (*this).ID = ID;
        (*this).date = date;
        (*this).query = query;
        (*this).user = user;
        sentiment = sent;
        text = tweet;
    };
};

class TokenScore {
public:

    TokenScore() = default;

    TokenScore(DSString tk, int s) { //constructor for token score
        token = tk; //token score
        score = s; //score
    }

    DSString token;
    int score;
};



class Dictionary {
public:
    float bias = 100; // most optimal bias from testing
    int rarity_threshold = 0; //most optimal threshold, the number of times a value can appear

    DSVector<TokenScore> tsVec; // dictionary token
    DSVector<TokenScore> tsVecCounting; // dictionary token

    void doAllTheTrainingHere(char*); //All training of data set is done
    void doAllTheTestingHere(char*, char*, char*, char*);  //All of the testing and output is done
    void update2(DSStringTokenizer);//function for updating the dictionary

    int predict(DSStringTokenizer DS, int rarity_threshold); //predict using paremter of threshold
    int predict(DSStringTokenizer);//Load in values of tweet and sentiment
    double evaluatePrediction(DSVector<Tweet2>); // evaluate prediction, loading the the vector
    double evaluatePrediction(DSVector<Tweet2>, float, int);  //use the vecotr, threshold and bias to compute and classify

};

#endif