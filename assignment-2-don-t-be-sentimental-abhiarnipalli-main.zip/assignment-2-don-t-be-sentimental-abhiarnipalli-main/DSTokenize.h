#ifndef _H_DSSTRINGTOKENIZER
#define _H_DSSTRINGTOKENIZER

#include <iostream>
//#include "vector.h"
#include <vector>
#include "DSString.h"
using namespace std;




class DSStringTokenizer{

public: //Compare negative tweet, and a positive tweet 

//Read negative twwet


    int sentiment;
    vector<DSString> tokenVec; //what we are reading

    DSStringTokenizer(int s, vector<DSString> tv){

        sentiment =s;
        tokenVec =tv;

    }
    DSStringTokenizer(int sent, DSString text) { // constructor for creating accuray



        sentiment = sent;
        tokenVec = Tokenization(text);



    }

    DSStringTokenizer(int sent, DSString text, vector<DSString> stpWrd) { //constructor for tokenizing the stop word

        sentiment = sent;
        tokenVec = Tokenization(text, stpWrd);
    }

    vector<DSString>  Tokenization(DSString Tweet) { //empty contstructor

        vector<DSString> empty;
        return Tokenization(Tweet, empty);
    }

    vector<DSString> Tokenization(DSString tweet, vector<DSString> stopwrd) { //Tokenization for a vector of stop words. Checking if the stop word exists or not.
        //If non existent, then stop words will be added.



        vector<DSString> tokenVec;

        int i;
        int j;

        // getline(tweet,token, ' ');

        i = tweet.find(' ');
        j = 0;


        bool flag = false;

        while (i != -1) {

            flag = false;

            DSString token(tweet.substring(j, i - j)); // Reads the stopword
            for (int k = 0; k < stopwrd.size(); k++) { // Goes through every stop word and checks if it exists


                if (token == stopwrd[k]) { //If the stop word is found it will not add into token vec
                    flag = true;
                    break;

                }

            }
            //find the next stop word
            j = i + 1;
            i = tweet.find(' ', j);
            if (flag) {

                continue;   // will continue through the for loop if the flag is true
            }
            tokenVec.push_back(token); // if the flag isn't true, then the value hasnt been seen and will be added to tokenVec


        }
        return tokenVec; //updates the vector of stop words and returns
    }






private:




};




#endif